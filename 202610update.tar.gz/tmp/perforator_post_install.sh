echo После обновления ваш ПК будет перезагружен, выйдите из всех приложений. Введите пароль.
sudo apt update
sudo apt install -y zram-tools
sudo systemctl enable zramswap
reboot
